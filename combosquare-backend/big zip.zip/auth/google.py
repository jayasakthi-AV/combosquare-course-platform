import os, json
from authlib.integrations.starlette_client import OAuth
from starlette.config import Config
from fastapi import APIRouter
from fastapi.responses import RedirectResponse
from starlette.requests import Request
from urllib.parse import urlencode

router = APIRouter()

config = Config(".env")
oauth = OAuth(config)
oauth.register(
    name="google",
    server_metadata_url="https://accounts.google.com/.well-known/openid-configuration",
    client_kwargs={"scope": "openid email profile"},
)

FRONTEND_URL = os.getenv("FRONTEND_URL", "http://localhost:5173")

@router.get("/auth/google")
async def google_login(request: Request):
    redirect_uri = request.url_for("google_callback")
    return await oauth.google.authorize_redirect(request, redirect_uri)


@router.get("/auth/google/callback", name="google_callback")
async def google_callback(request: Request):
    token = await oauth.google.authorize_access_token(request)
    user_info = token.get("userinfo")

    email = user_info["email"]
    name = user_info.get("name", "")

    # Get or create user in your DB
    user = await get_or_create_user(email=email, full_name=name)

    # Create your JWT the same way you do in /login
    access_token = create_access_token({"sub": str(user.id), "role": user.role})

    # Redirect back to frontend with token
    user_data = urlencode({"token": access_token, "user": json.dumps({"id": user.id, "email": user.email, "role": user.role, "full_name": user.full_name})})
    return RedirectResponse(url=f"{FRONTEND_URL}/login?{user_data}")