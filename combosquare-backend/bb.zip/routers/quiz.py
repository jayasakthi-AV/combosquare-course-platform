from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from pydantic import BaseModel
from database import get_db
from models.progress import Progress
from models.quiz import Quiz
from core.dependencies import get_current_user

router = APIRouter()


class QuizSubmit(BaseModel):
    lesson_id: int
    answer: str


# ✅ GET QUIZ FOR A LESSON (from DB)
@router.get("/lesson/{lesson_id}")
def get_quiz(
    lesson_id: int,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user)
):
    # 🔒 Must have completed watching the video first
    progress = db.query(Progress).filter_by(
        user_id=current_user.id,
        lesson_id=lesson_id
    ).first()

    if not progress or not progress.completed:
        raise HTTPException(
            status_code=403,
            detail="You must finish watching the video before taking the quiz"
        )

    quiz = db.query(Quiz).filter_by(lesson_id=lesson_id).first()

    if not quiz:
        # No quiz for this lesson — auto-mark as passed so next unlocks
        progress.quiz_passed = True
        db.commit()
        return {"no_quiz": True, "message": "No quiz for this lesson. Next lesson unlocked!"}

    return {
        "id": quiz.id,
        "question": quiz.question,
        "options": [quiz.option1, quiz.option2, quiz.option3, quiz.option4],
    }


# ✅ SUBMIT QUIZ ANSWER
# routes/quiz.py — replace the submit endpoint

@router.post("/submit")
def submit_quiz(
    data: QuizSubmit,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user)
):
    progress = db.query(Progress).filter_by(
        user_id=current_user.id,
        lesson_id=data.lesson_id
    ).first()

    if not progress or not progress.completed:
        raise HTTPException(status_code=403, detail="Finish watching the video first")

    quiz = db.query(Quiz).filter_by(lesson_id=data.lesson_id).first()
    if not quiz:
        raise HTTPException(status_code=404, detail="No quiz found")

    is_correct = data.answer.strip().lower() == quiz.answer.strip().lower()

    if is_correct:
        progress.quiz_passed = True
        db.commit()

        # ── Find next lesson (across modules) ──────────────────────────────
        from models.lesson import Lesson
        from models.module import Module

        current_lesson = db.query(Lesson).filter_by(id=data.lesson_id).first()
        if not current_lesson:
            return {"passed": True, "message": "Correct!"}

        current_module = db.query(Module).filter_by(
            id=current_lesson.module_id
        ).first()

        # 1. Try next lesson in same module
        next_lesson = (
            db.query(Lesson)
            .filter(
                Lesson.module_id == current_lesson.module_id,
                Lesson.order > current_lesson.order
            )
            .order_by(Lesson.order)
            .first()
        )

        # 2. If no next lesson in module → find first lesson of next module
        if not next_lesson:
            next_module = (
                db.query(Module)
                .filter(
                    Module.course_id == current_module.course_id,
                    Module.order > current_module.order
                )
                .order_by(Module.order)
                .first()
            )
            if next_module:
                next_lesson = (
                    db.query(Lesson)
                    .filter_by(module_id=next_module.id)
                    .order_by(Lesson.order)
                    .first()
                )

        if next_lesson:
            next_lesson.unlocked = True
            db.commit()
            print(f"✅ Unlocked: [{next_lesson.id}] {next_lesson.title}")
        else:
            print("🎓 Course complete — no next lesson")

    return {
        "passed": is_correct,
        "correct_answer": quiz.answer if not is_correct else None,
        "message": "Correct! Next lesson unlocked." if is_correct else "Wrong answer, try again.",
    }